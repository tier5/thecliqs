<?php


return array(

  'package' => array(

    'type' => 'widget',

    'name' => 'jqmenuselect',

    'version' => '1.0',

    'path' => 'application/widgets/jqmenuselect',

    'repository' => 'starsdeveloper.com',

    'meta' => array(

      'title' => 'jqmenuselect',

      'description' => 'Gives Active Class To Main Menu Items',

      'author' => 'starsdeveloper.com',

    ),

    'directories' => array(

      'application/widgets/jqmenuselect',

    ),

  ),



  // Backwards compatibility

  'type' => 'widget',

  'name' => 'jqmenuselect',

  'version' => '1.0',

  'title' => 'jqmenuselect',

  'description' => 'Gives Active Class To Main Menu Items.',

  'category' => 'Widgets',

) ?>