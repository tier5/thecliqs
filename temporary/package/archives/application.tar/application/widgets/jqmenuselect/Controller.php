<?php
/**
 * SocialEngine
 *
 * @category   Application_Widgets
 * @copyright  Copyright 20011-2012 Stars Developer
 * @version    1.0
 * @author     StarsDeveloper
 */
class Widget_JqmenuselectController extends Engine_Content_Widget_Abstract
{
  public function indexAction()
  {
  
  }
}