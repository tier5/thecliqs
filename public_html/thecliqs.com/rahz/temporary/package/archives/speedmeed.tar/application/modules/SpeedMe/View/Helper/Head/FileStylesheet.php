<?php

/**
 * Processor for handling operation with css files
 *
 * @package    View
 * @subpackage Helper
 * @version    0.0.1
 * @author     Alexey S. Kachayev <kachayev@gmail.com>
 * @link       https://github.com/kachayev/zend-fw-head-SpeedMe
 */
class SpeedMe_View_Helper_Head_FileStylesheet
    extends SpeedMe_View_Helper_Head_File
{

    /**
     * Return path to file described in item
     *
     * @param  stdClass $item
     * @return string|null
     */
    protected function _getItemPath($item)
    {
        $path = null;
        if (!empty($item->href)) {
            $path = $item->href;
            if (strpos($path, '?')) {
                $path = parse_url($path, PHP_URL_PATH);
            }
        }
        return $path;
    }

    /**
     * Return conditional attributes for item
     *
     * @param  stdClass $item
     * @return string|null
     */
    protected function _getItemConditional($item)
    {
        return isset($item->conditionalStylesheet) ? $item->conditionalStylesheet : false;
    }
}