<?php
//List of files, which need to exclude from processing, preg_match syntax
return array(
    '/tiny_mce\.js/',
);