<?php
ini_set("memory_limit","80M");
class SpeedMe_View_Helper_HeadScript extends Zend_View_Helper_HeadScript
{
    /**
     * @var string
     */
    protected $_defaultCacheDir = '/externals/cache/js/';

    /**
     * Object for file processing
     *
     * @var SpeedMe_View_Helper_Head_File
     */
    protected $_processor = null;

    /**
     *
     * @var Zend_Http_Uri
     */
    protected $_uri;

    /**
     * Constructor
     *
     * Set separator to PHP_EOL.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
        $this->_defaultCacheDir = '/application/modules/SpeedMe'
                                  . $this->_defaultCacheDir;
        $this->setConfig();
    }

    /**
     * Retrieve string representation
     *
     * @param  string|int $indent
     * @return string
     */
    public function scriptsToString($indent = null)
    {
        $headScript = $this->view->headScript();
        $indent     = is_null($indent) ? $headScript->getIndent() : $headScript->getWhitespace($indent);
        $useCdata   = ($this->view) ? $this->view->doctype()->isXhtml() : (bool) $headScript->useCdata;

        list($escapeStart, $escapeEnd) = ($useCdata) ? array('//<![CDATA[','//]]>') : array('//<!--','//-->');

        $items = array();
        $headScript->getContainer()->ksort();
        foreach ($headScript as $item) {
            //process only external js files
            if (!$headScript->_isValid($item)) {
                // Pass item adding for invalid one
                continue;
            }

            // Check if this item cachable and create specific container for it if necessary
            // @TODO "raw" scripts on page cannot be cached due to SN issue with dymanic variables inside them
            if (empty($item->attributes['src']) || !$this->getProcessor()->isCachable($item)) {
                $items[] = $this->itemToString($item, $indent, $escapeStart, $escapeEnd);
            } else {
                $this->getProcessor()->cache($item);
            }
        }

        // Add to items list HTML container with compiled items
        array_unshift($items, $this->itemToString($this->_getCompiledItem(), $indent, $escapeStart, $escapeEnd));

        // Return string representaion for all HTML containers
        return implode($headScript->getSeparator(), $items);
    }

    public function toString()
    {
        return $this->getOption('combine', true) ? $this->scriptsToString() : $this->view->headScript();
    }

    /**
     * Compile full list of files in $this->_cache array
     *
     * @return string
     */
    protected function _getCompiledItem()
    {
        $fileProcessor = $this->getProcessor();
        $cache = $fileProcessor->getCache();
        $serialize = serialize($cache);
        $md5 = md5($serialize);
        $path = $fileProcessor->getServerPath(
            $this->getOption('dir') . $fileProcessor->fullFilename($md5)
        );

        if (!file_exists($path)) {
            // Check if necessary directory is exists
            $dir = dirname($path);
            if (!is_dir($dir) && !@mkdir($dir, 0777, true)) {
                // @todo: Use more specific exception here
                throw new Zend_View_Exception('Impossible to create destination directory ' . $dir);
            }

            // Build file content
            $jsContent = '';
            foreach ($fileProcessor->getCache() as $js) {
                $rawJs = (is_array($js) ? file_get_contents($js['filepath']) : $js);
                // Minify by using 3rd-party library
                if ($this->getOption('compress')) {
                    //check the compression is necessary, file has spaces
                    if (preg_match('/\s/', $rawJs)) {
                        if( !ini_get('safe_mode') ){
                            $maxExecutionTime = 540;
                            if ( ini_get('max_execution_time')<$maxExecutionTime ) {
                                set_time_limit($maxExecutionTime);
                            }
                        }

                        require_once dirname(__FILE__).DS.'..'.DS.'..'.DS.'Model'.DS.'JSMinPlus.php';
			             $rawJs = JSMinPlus::minify($rawJs);
                        //require_once dirname(__FILE__).DS.'..'.DS.'..'.DS.'Model'.DS.'JSMin.php';
                        //$rawJs = JSMin::minify($rawJs);
                    }
                }
                $jsContent .= $rawJs . "\n;";
            }

            

            // Write js content to file
            file_put_contents($path, $jsContent);
            $fileProcessor->gzip($path, $jsContent);
            
        }
        return $this->createData('text/javascript', array('src' => $fileProcessor->getWebPath($path)));
    }

    /**
     * Set configuration, possible to use array or Zend_Config object
     *
     * @param  array|Zend_Config $config
     * @return null
     */
    public function setConfig($config=null)
    {
        if ($config instanceof Zend_Config) {
            $config = $config->toArray();
        } elseif (!is_array($config)) {
            $config = array();
        }

        // Merge default configuration
        $config = array_merge(array('dir'=>$this->_defaultCacheDir,'extension'=>'js'),$config);
        return $this->getProcessor()->setConfig($config);
    }

    /**
     * Return option from current object configuration
     *
     * @param  string $name
     * @param  mixed  $defaultValue
     * @return mixed
     */
    public function getOption($name, $defaultValue=null)
    {
        return $this->getProcessor()->getOption($name, $defaultValue);
    }

    /**
     * Create file processing object or return existen
     *
     * @return SpeedMe_View_Helper_Head_File
     */
    public function getProcessor() {
        if(null === $this->_processor) {
            $this->setProcessor(new SpeedMe_View_Helper_Head_File());
        }

        return $this->_processor;
    }

    /**
     * Set file processor object using FileAbstract for dependency keeping
     *
     * @param  SpeedMe_View_Helper_Head_FileAbstract $processor
     * @return $this
     */
    public function setProcessor(SpeedMe_View_Helper_Head_FileAbstract $processor)
    {
        $this->_processor = $processor;
        return $this;
    }

}
